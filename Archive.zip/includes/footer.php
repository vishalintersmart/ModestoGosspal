<footer>

    <section id="copYRight">
        <div class="container">
            <div class="flexRow">
                <div class="lftSec">
                    Copyright © <?= date('Y') ?> <span>Asha Sarath Collections.</span> All Rights Reserved
                </div>
                <div class="ritSec">
                    <div class="designed">
                        Designed By:
                        <a href="https://intersmartsolution.com" target="_blank">
                            intersmart
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

</footer>
</div>


<a href="#" class="scrollup">
    <svg viewBox="0 0 10 37">
        <path
            d="M5.478,0.179 L9.802,4.415 C10.066,4.674 10.066,5.093 9.802,5.351 C9.538,5.610 9.110,5.610 8.847,5.351 L5.676,2.245 L5.676,36.337 C5.676,36.702 5.373,36.998 5.000,36.998 C4.627,36.998 4.324,36.702 4.324,36.337 L4.324,2.245 L1.153,5.351 C0.889,5.610 0.462,5.610 0.198,5.351 C0.066,5.222 -0.000,5.052 -0.000,4.883 C-0.000,4.714 0.066,4.545 0.198,4.415 L4.522,0.179 C4.786,-0.080 5.214,-0.080 5.478,0.179 Z">
        </path>
    </svg>
    Top
</a>

<?php include "./includes/MobMenu.php"?>

<!-- JARALLAX -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.0.3/jarallax.min.css"
    integrity="sha512-djZM2MOGEKiRnvoeu99OJUvkbkosoy1yIhQ+t6cONb90qjtQ8hxuoCxKK5k5eSvlWqb4887+ld9J82nzlwiqYQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.0.3/jarallax.min.js"
    integrity="sha512-bb6SckWHWfSVlF459oTkPxiprNFEv5nmXvyHSBAH00eG799zXU8w3iM2i7878FHuZsAPZEUjwQqlWM9QKz5DAQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- AOS --->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<!-- CUSTOME --->
<script type="text/javascript" src="assets/js/app.js"></script>

</body>

</html>